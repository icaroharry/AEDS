double cauchy(double x);

double gumbel(double x, double mi, double beta);

double laplace(double x, double mi, double b);
